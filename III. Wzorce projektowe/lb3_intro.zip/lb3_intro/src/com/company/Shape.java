package com.company;

public interface Shape {
    String toSvg();

}
